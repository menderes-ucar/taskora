enum ContractStatus {
  active,
  funded,
  workSubmitted,
  revisionRequested,
  delivered,
  completed,
  cancelled,
}

extension ContractStatusX on ContractStatus {
  String get label {
    switch (this) {
      case ContractStatus.active:
        return 'Aktif';
      case ContractStatus.funded:
        return 'Bakiye Havuzda';
      case ContractStatus.workSubmitted:
        return 'İş Teslim Edildi';
      case ContractStatus.revisionRequested:
        return 'Revizyon İstendi';
      case ContractStatus.delivered:
        return 'Onay Bekliyor';
      case ContractStatus.completed:
        return 'Tamamlandı';
      case ContractStatus.cancelled:
        return 'İptal Edildi';
    }
  }

  static ContractStatus fromString(String? value) {
    if (value == null) return ContractStatus.active;
    switch (value.toLowerCase()) {
      case 'funded':
        return ContractStatus.funded;
      case 'work_submitted':
      case 'worksubmitted':
        return ContractStatus.workSubmitted;
      case 'revision_requested':
      case 'revisionrequested':
        return ContractStatus.revisionRequested;
      case 'delivered':
        return ContractStatus.delivered;
      case 'completed':
        return ContractStatus.completed;
      case 'cancelled':
        return ContractStatus.cancelled;
      case 'active':
      default:
        return ContractStatus.active;
    }
  }
}