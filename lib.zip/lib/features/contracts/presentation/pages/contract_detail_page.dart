import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../app/theme/app_colors.dart';
import '../../../../../shared/enums/contract_status.dart';
import '../../../../../shared/enums/payment_status.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../logic/contracts_provider.dart';

class ContractDetailPage extends ConsumerWidget {
  final String contractId;

  const ContractDetailPage({
    super.key,
    required this.contractId,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentUser = ref.watch(authProvider).user;
    final contractsAsync = ref.watch(contractsProvider);

    return Scaffold(
      backgroundColor: AppColors.primary,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        elevation: 0,
        title: const Text(
          'Sözleşme & Proje Detayı',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: contractsAsync.when(
        data: (contracts) {
          final contract = contracts.firstWhere(
                (c) => c.id == contractId,
            orElse: () => throw Exception('Sözleşme bulunamadı'),
          );

          final isEmployer = currentUser?.id == contract.employerId;
          final isFreelancer = currentUser?.id == contract.freelancerId;

          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              // 🚀 Proje Başlık Kartı
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      contract.jobTitle,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppColors.black,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Anlaşılan Tutar: ₺${contract.agreedAmount.toStringAsFixed(0)}',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: AppColors.primaryDark,
                          ),
                        ),
                        Text(
                          '${contract.deliveryDays} Gün Teslim',
                          style: const TextStyle(
                            color: AppColors.grey,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),
              const Text(
                'SaaS Proje Süreç Aşamaları',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),

              // 🚀 Proje Adımları (Milestones Timeline)
              _buildTimelineStep(
                title: '1. Sözleşme Oluşturuldu',
                subtitle: 'İşveren ve Freelancer anlaştı.',
                isDone: true,
              ),
              _buildTimelineStep(
                title: '2. Güvenli Havuz Ödemesi (Escrow)',
                subtitle: contract.paymentStatus == PaymentStatus.funded ||
                    contract.paymentStatus == PaymentStatus.released
                    ? 'Tutar havuzda güvence altında.'
                    : 'İşverenin bakiyeyi havuza aktarması bekleniyor.',
                isDone: contract.paymentStatus == PaymentStatus.funded ||
                    contract.paymentStatus == PaymentStatus.released,
              ),
              _buildTimelineStep(
                title: '3. İş Teslimi',
                subtitle: contract.status == ContractStatus.delivered ||
                    contract.status == ContractStatus.completed
                    ? 'Freelancer işi tamamladı ve teslim etti.'
                    : 'Freelancer çalışmayı yürütüyor.',
                isDone: contract.status == ContractStatus.delivered ||
                    contract.status == ContractStatus.completed,
              ),
              _buildTimelineStep(
                title: '4. Onay & Bakiye Aktarımı',
                subtitle: contract.status == ContractStatus.completed
                    ? 'İşveren onayladı, ödeme aktarıldı.'
                    : 'İşverenin işi kontrol edip onaylaması bekleniyor.',
                isDone: contract.status == ContractStatus.completed,
              ),

              const SizedBox(height: 32),

              // 🚀 SaaS Aksiyon Butonları (Rol Bazlı)
              if (isEmployer) ...[
                if (contract.paymentStatus == PaymentStatus.pending)
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.success,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                    icon: const Icon(Icons.account_balance_wallet_rounded,
                        color: Colors.white),
                    label: const Text(
                      'Ödemeyi Havuza Aktar (Escrow)',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                    onPressed: () async {
                      await ref
                          .read(contractsProvider.notifier)
                          .fundContract(contract.id);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text('Tutar güvenli havuza aktarıldı!')),
                        );
                      }
                    },
                  ),
                if (contract.status == ContractStatus.delivered)
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryDark,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                    icon: const Icon(Icons.check_circle_rounded,
                        color: Colors.white),
                    label: const Text(
                      'İşi Onayla & Ödemeyi Freelancer\'a Aktar',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                    onPressed: () async {
                      await ref
                          .read(contractsProvider.notifier)
                          .completeContract(contract.id);
                      await ref
                          .read(contractsProvider.notifier)
                          .releasePayment(contract.id);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text(
                                  'Proje tamamlandı! Bakiye serbest bırakıldı.')),
                        );
                      }
                    },
                  ),
              ],

              if (isFreelancer) ...[
                if (contract.paymentStatus == PaymentStatus.funded &&
                    contract.status != ContractStatus.delivered &&
                    contract.status != ContractStatus.completed)
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.warning,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                    icon: const Icon(Icons.send_rounded, color: Colors.white),
                    label: const Text(
                      'İşi Tamamla & Teslim Et',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                    onPressed: () async {
                      await ref
                          .read(contractsProvider.notifier)
                          .deliverContract(contract.id);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text(
                                  'İş işverene teslim edildi. Onay bekleniyor.')),
                        );
                      }
                    },
                  ),
              ],
            ],
          );
        },
        loading: () => const Center(
            child: CircularProgressIndicator(color: Colors.white)),
        error: (err, _) => Center(
            child: Text('Hata: $err',
                style: const TextStyle(color: Colors.white))),
      ),
    );
  }

  Widget _buildTimelineStep({
    required String title,
    required String subtitle,
    required bool isDone,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDone ? AppColors.success : AppColors.grey.withAlpha(50),
          width: 2,
        ),
      ),
      child: Row(
        children: [
          Icon(
            isDone ? Icons.check_circle_rounded : Icons.radio_button_unchecked,
            color: isDone ? AppColors.success : AppColors.grey,
            size: 28,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: isDone ? AppColors.black : AppColors.grey,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 12, color: AppColors.grey),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}