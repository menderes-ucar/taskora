import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:taskora/features/notification/data/services/notification_helper.dart';

import '../../../../shared/enums/app_notification_type.dart';
import '../../../../shared/enums/contract_status.dart';
import '../../../../shared/enums/payment_status.dart';
import '../../../../shared/models/contract_model.dart';

import '../data/contract_repository_provider.dart';

class ContractsNotifier extends AsyncNotifier<List<ContractModel>> {
  StreamSubscription<List<Map<String, dynamic>>>? _subscription;

  @override
  Future<List<ContractModel>> build() async {
    _initRealtimeStream();
    return _loadContracts();
  }

  void _initRealtimeStream() {
    _subscription?.cancel();
    try {
      final client = Supabase.instance.client;

      _subscription = client
          .from('contracts')
          .stream(primaryKey: ['id'])
          .order('created_at', ascending: false)
          .listen(
            (data) {
          final contracts =
          data.map((map) => ContractModel.fromMap(map)).toList();
          state = AsyncValue.data(contracts);
        },
        onError: (error, stack) async {
          debugPrint('⚠️ [Realtime Contracts Hata]: $error');

          // JWT Token süresi dolduysa oturumu yenile ve yayını tekrar başlat
          if (error.toString().contains('invalidJWTToken') ||
              error.toString().contains('expired')) {
            try {
              await client.auth.refreshSession();
              _initRealtimeStream();
            } catch (e) {
              _loadContracts().then((list) => state = AsyncValue.data(list));
            }
          } else {
            state = AsyncValue.error(error, stack);
          }
        },
      );
    } catch (e) {
      debugPrint('⚠️ [Realtime Subscription Error]: $e');
    }

    ref.onDispose(() {
      _subscription?.cancel();
    });
  }

  Future<List<ContractModel>> _loadContracts() async {
    final repository = ref.read(contractRepositoryProvider);
    return repository.getAllContracts();
  }

  Future<void> refreshContracts() async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(() async => _loadContracts());
  }

  ContractModel? getById(String contractId) {
    final contracts = state.valueOrNull ?? [];
    try {
      return contracts.firstWhere((contract) => contract.id == contractId);
    } catch (_) {
      return null;
    }
  }

  ContractModel? getByJobId(String jobId) {
    final contracts = state.valueOrNull ?? [];
    try {
      return contracts.firstWhere((contract) => contract.jobId == jobId);
    } catch (_) {
      return null;
    }
  }

  List<ContractModel> getByFreelancer(String freelancerId) {
    final contracts = state.valueOrNull ?? [];
    return contracts
        .where((contract) => contract.freelancerId == freelancerId)
        .toList();
  }

  List<ContractModel> getByEmployer(String employerId) {
    final contracts = state.valueOrNull ?? [];
    return contracts
        .where((contract) => contract.employerId == employerId)
        .toList();
  }

  bool hasContractForJob(String jobId) {
    final contracts = state.valueOrNull ?? [];
    return contracts.any((contract) => contract.jobId == jobId);
  }

  Future<void> addContract(ContractModel contract) async {
    final repository = ref.read(contractRepositoryProvider);
    await repository.addContract(contract);

    NotificationHelper.send(
      targetUserId: contract.freelancerId,
      title: 'Yeni sözleşme oluşturuldu',
      body: '${contract.jobTitle} işi için sözleşme oluşturuldu.',
      type: AppNotificationType.contractCreated.name,
      relatedId: contract.id,
    );
  }

  Future<void> updateContractStatus(
      String contractId,
      ContractStatus status,
      ) async {
    final repository = ref.read(contractRepositoryProvider);
    final contract = getById(contractId);

    await repository.updateContractStatus(contractId, status);

    if (contract == null) return;

    if (status == ContractStatus.delivered) {
      NotificationHelper.send(
        targetUserId: contract.employerId,
        title: 'İş teslim edildi',
        body: '${contract.jobTitle} işi freelancer tarafından teslim edildi.',
        type: AppNotificationType.workSubmitted.name,
        relatedId: contract.id,
      );
    }

    if (status == ContractStatus.completed) {
      NotificationHelper.send(
        targetUserId: contract.freelancerId,
        title: 'Proje tamamlandı',
        body: '${contract.jobTitle} işi tamamlandı olarak işaretlendi.',
        type: AppNotificationType.contractCompleted.name,
        relatedId: contract.id,
      );
    }
  }

  Future<void> fundContract(String contractId) async {
    final repository = ref.read(contractRepositoryProvider);
    await repository.updatePaymentStatus(contractId, PaymentStatus.funded);
  }

  Future<void> releasePayment(String contractId) async {
    final repository = ref.read(contractRepositoryProvider);
    await repository.updatePaymentStatus(contractId, PaymentStatus.released);
  }

  Future<void> deliverContract(String contractId) async {
    await updateContractStatus(contractId, ContractStatus.delivered);
  }

  Future<void> completeContract(String contractId) async {
    await updateContractStatus(contractId, ContractStatus.completed);
  }
}

final contractsProvider =
AsyncNotifierProvider<ContractsNotifier, List<ContractModel>>(
  ContractsNotifier.new,
);