import 'package:flutter_riverpod/flutter_riverpod.dart' as rp;
import 'package:supabase_flutter/supabase_flutter.dart';

import 'contract_repository.dart';
import 'supabase_contract_repository.dart';

final contractSupabaseClientProvider = rp.Provider<SupabaseClient>((ref) {
  return Supabase.instance.client;
});

final contractRepositoryProvider = rp.Provider<ContractRepository>((ref) {
  final supabase = ref.watch(contractSupabaseClientProvider);
  return SupabaseContractRepository(supabase);
});